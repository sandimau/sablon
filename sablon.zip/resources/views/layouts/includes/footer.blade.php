<footer class="footer text-sm">
    <div>
        Copyright &copy; {{ date('Y') }}
    </div>
    <div class="ms-auto">Bootstrap Admin Template</div>
</footer>
