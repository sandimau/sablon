@extends('layouts.app')

@section('title')
    Data Omzet
@endsection

@section('content')
    <div class="bg-light rounded">
        <div class="card">
            <canvas id="speedChart"></canvas>
        </div>
    </div>
    @php @endphp
@endsection

@push('after-scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var speedCanvas = document.getElementById("speedChart");

        var dataFirst = {
            label: @php
                $data = null;
                if ($last->first()) {
                    $data = $last->first()->year;
                }
            echo '"omzet ' . $data . '"'; @endphp,
            data: [
                @php
                    foreach ($last as $value) {
                        echo $value->omzet . ',';
                    }
                @endphp
            ],
            lineTension: 0,
            fill: false,
            borderColor: 'red'
        };

        var dataSecond = {
            label: @php echo '"omzet '.$years->first()->year . '"' @endphp,
            data: [
                @php
                    foreach ($years as $value) {
                        echo $value->omzet . ',';
                    }
                @endphp
            ],
            lineTension: 0,
            fill: false,
            borderColor: 'blue'
        };

        var speedData = {
            labels: [
                @php
                    foreach ($years as $value) {
                        echo '"' . $value->monthname . '",';
                    }
                @endphp
            ],
            datasets: [dataFirst, dataSecond]
        };

        var chartOptions = {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    boxWidth: 80,
                    fontColor: 'black'
                }
            }
        };

        var lineChart = new Chart(speedCanvas, {
            type: 'line',
            data: speedData,
            options: chartOptions
        });
    </script>
@endpush
