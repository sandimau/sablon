<?php $__env->startSection('title'); ?>
    Data Belanja
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="mt-2">
            <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Belanjas</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your belanja here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member_create')): ?>
                        <a href="<?php echo e(route('belanja.create')); ?>" class="btn btn-primary"><i class='bx bx-plus-circle'></i> Add</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php echo e($belanjas->links()); ?>

                <div class="table-responsive">
                    <table class=" table table-bordered table-striped table-hover mt-3">
                        <thead>
                            <tr>
                                <th>tanggal</th>
                                <th>supplier</th>
                                <th>produk</th>
                                <th>nota</th>
                                <th>total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $belanjas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $belanja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($belanja->id); ?>">
                                    <td><?php echo e(date('d-m-Y', strtotime(($belanja->created_at)))); ?></td>
                                    <td><?php echo e($belanja->kontak->nama); ?></td>
                                    <td><a href="<?php echo e(route('belanja.detail',$belanja->id)); ?>"><?php echo e($belanja->produk); ?></a></td>
                                    <td>#<?php echo e($belanja->nota); ?></td>
                                    <td><?php echo e(number_format($belanja->total, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/belanjas/index.blade.php ENDPATH**/ ?>