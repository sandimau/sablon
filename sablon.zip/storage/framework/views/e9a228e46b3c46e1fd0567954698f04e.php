<footer class="footer text-sm">
    <div>
        Copyright &copy; <?php echo e(date('Y')); ?>

    </div>
    <div class="ms-auto">Bootstrap Admin Template</div>
</footer>
<?php /**PATH C:\laragon\www\sablon\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>