<?php $__env->startSection('title'); ?>
    Level List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Level</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your level here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('level_create')): ?>
                        <a href="<?php echo e(route('level.create')); ?>" class="btn btn-primary ">Add level</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">nama</th>
                                <th scope="col">gaji pokok</th>
                                <th scope="col">komunikasi</th>
                                <th scope="col">transportasi</th>
                                <th scope="col">kehadiran</th>
                                <th scope="col">lama kerja (%)</th>
                                <th scope="col">actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($level->nama); ?></td>
                                    <td><?php echo e(number_format($level->gaji_pokok)); ?></td>
                                    <td><?php echo e(number_format($level->komunikasi)); ?></td>
                                    <td><?php echo e(number_format($level->transportasi)); ?></td>
                                    <td><?php echo e(number_format($level->kehadiran)); ?></td>
                                    <td><?php echo e(number_format($level->lama_kerja)); ?></td>
                                    <td><?php echo e(number_format($level->harga_lembur)); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('level.edit', $level->id)); ?>" class="btn btn-info btn-sm me-1"><i
                                                    class='bx bxs-edit'></i> Edit</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/levels/index.blade.php ENDPATH**/ ?>