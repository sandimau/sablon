<?php $__env->startSection('title'); ?>
    Data Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Members</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your members here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member_create')): ?>
                        <a href="<?php echo e(route('members.create')); ?>" class="btn btn-primary"><i class='bx bx-plus-circle'></i> Add</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class=" table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>nama lengkap</th>
                                <th>cuti</th>
                                <th>ijin</th>
                                <th>kasbon</th>
                                <th>lembur</th>
                                <th>tunjangan</th>
                                <th>umur</th>
                                <th>lama kerja</th>
                                <th>tanggal gajian</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($member->id); ?>">
                                    <td>
                                        <a href="<?php echo e(route('members.show', $member->id)); ?>"><?php echo e($member->nama_lengkap ?? ''); ?></a>
                                    </td>
                                    <td><?php echo e($member->countCuti); ?></td>
                                    <td><?php echo e($member->countIjin); ?></td>
                                    <td><?php echo e(number_format($member->countKasbon)); ?></td>
                                    <td><?php echo e($member->countLembur); ?></td>
                                    <td><?php echo e(number_format($member->countTunjangan)); ?></td>
                                    <td><?php echo e($member->umur ?? ''); ?></td>
                                    <td><?php echo e($member->lamaKerja ?? ''); ?></td>
                                    <td><?php echo e($member->tgl_gajian); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/members/index.blade.php ENDPATH**/ ?>