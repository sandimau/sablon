<?php $__env->startSection('title'); ?>
Edit Akun Kategoris
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        Edit Akun Kategoris
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("akunKategoris.update", [$akunKategori->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="nama">nama</label>
                <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama" id="nama" value="<?php echo e(old('nama', $akunKategori->nama)); ?>">
                <?php if($errors->has('nama')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label for="akun_id">akun</label>
                <select class="form-select <?php echo e($errors->has('akun_id') ? 'is-invalid' : ''); ?>" aria-label="Default select example" name="akun_id" id="akun_id">
                    <?php $__currentLoopData = $akuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('akun_id') ? old('akun_id') : $akunKategori->akun->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('akun')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('akun')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/akunKategoris/edit.blade.php ENDPATH**/ ?>