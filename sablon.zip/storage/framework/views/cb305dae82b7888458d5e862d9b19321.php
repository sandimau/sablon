<?php $__env->startSection('title'); ?>
    Proses Produksi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-details-center">
                            <div>
                                <h5 class="card-title">Order Detail</h5>
                            </div>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kontak_create')): ?>
                                <a href="<?php echo e(route('kontaks.create')); ?>" class="btn btn-primary">Add kontaks</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped" id="myTable">
                            <thead>
                                <tr>
                                    <th>produk</th>
                                    <th>tema</th>
                                    <th>jml</th>
                                    <th>harga</th>
                                    <th>subtotal</th>
                                    <th>spesifikasi</th>
                                    <th>status</th>
                                    <th>gambar</th>
                                    <th>deadline</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->orderDetail()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($detail->produk->nama); ?></td>
                                        <td><?php echo e($detail->tema); ?></td>
                                        <td><?php echo e($detail->jumlah); ?></td>
                                        <td><?php echo e(number_format($detail->harga)); ?></td>
                                        <td><?php echo e(number_format($detail->harga * $detail->jumlah)); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $detail->spek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span style="font-weight: 600"> <?php echo e($spek->nama); ?>: </span>
                                                <?php echo e($spek->pivot->keterangan); ?>,
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php if(!empty($detail->keterangan)): ?>
                                                <span class='text-danger'> keterangan:</span>
                                                <?php echo e($detail->keterangan); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td></td>
                                        <td></td>
                                        <td><?php echo e($detail->deathline); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orders/detail.blade.php ENDPATH**/ ?>