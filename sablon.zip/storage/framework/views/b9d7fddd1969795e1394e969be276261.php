<?php $__env->startSection('title'); ?>
    Edit Produksi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5>Edit Produksi</h5>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('produksis.update', [$produksi->id])); ?>" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama" id="nama" value="<?php echo e(old('nama',$produksi->nama)); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="warna">Warna</label>
                    <input class="form-control <?php echo e($errors->has('warna') ? 'is-invalid' : ''); ?>" type="color" name="warna" id="warna" value="<?php echo e(old('warna',$produksi->warna)); ?>">
                    <?php if($errors->has('warna')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('warna')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>grup</label>
                    <select class="form-control <?php echo e($errors->has('warna') ? 'is-invalid' : ''); ?>" name="grup" >
                        <option>pilih grup</option>
                        <option value="awal" <?php echo e($produksi->grup == 'awal' ? 'selected' : ''); ?>>awal</option>
                        <option value="produksi" <?php echo e($produksi->grup == 'produksi' ? 'selected' : ''); ?>>produksi</option>
                        <option value="selesai" <?php echo e($produksi->grup == 'selesai' ? 'selected' : ''); ?>>selesai</option>
                    </select>
                    <?php if($errors->has('grup')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('grup')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        Udpate
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/produksis/edit.blade.php ENDPATH**/ ?>