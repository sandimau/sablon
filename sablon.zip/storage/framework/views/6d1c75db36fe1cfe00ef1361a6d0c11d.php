<?php $__env->startSection('title'); ?>
    Create Gaji
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            tambah gaji
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('gaji.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="member_id" value="<?php echo e($member->id); ?>">
                <div class="form-group mb-3">
                    <label for="bagian_id">Bagian</label>
                    <select class="form-select <?php echo e($errors->has('bagian_id') ? 'is-invalid' : ''); ?>" aria-label="Default select example" name="bagian_id"
                        id="bagian_id">
                        <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(($gaji ? $gaji->bagian->id == $id : null) ? 'selected' : ''); ?>>
                                <?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('bagian_id')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('bagian_id')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="level_id">level</label>
                    <select class="form-select <?php echo e($errors->has('level_id') ? 'is-invalid' : ''); ?>" aria-label="Default select example" name="level_id"
                        id="level_id">
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(($gaji ? $gaji->level->id == $id : null) ? 'selected' : ''); ?>>
                                <?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('level_id')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('level_id')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="performance">performance</label>
                    <select class="form-select <?php echo e($errors->has('performance') ? 'is-invalid' : ''); ?>" aria-label="Default select example"
                        name="performance" id="performance">
                        <option>pilih performance</option>
                        <option value="0" <?php echo e(($gaji ? $gaji->performance == 0 : null) ? 'selected' : ''); ?>>0</option>
                        <option value="1" <?php echo e(($gaji ? $gaji->performance == 1 : null) ? 'selected' : ''); ?>>1</option>
                        <option value="2" <?php echo e(($gaji ? $gaji->performance == 2 : null) ? 'selected' : ''); ?>>2</option>
                        <option value="3" <?php echo e(($gaji ? $gaji->performance == 3 : null) ? 'selected' : ''); ?>>3</option>
                        <option value="4" <?php echo e(($gaji ? $gaji->performance == 4 : null) ? 'selected' : ''); ?>>4</option>
                        <option value="5" <?php echo e(($gaji ? $gaji->performance == 5 : null) ? 'selected' : ''); ?>>5</option>
                    </select>
                    <?php if($errors->has('performance')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('performance')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <div class="form-check form-switch">
                        <input name="transportasi" class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" <?php echo e(($gaji ? $gaji->transportasi : null) ? 'checked' : ''); ?> >
                        <label class="form-check-label" for="flexSwitchCheckDefault">Transportasi</label>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="lain_lain">Tunjangan Lain</label>
                    <input class="form-control <?php echo e($errors->has('lain_lain') ? 'is-invalid' : ''); ?>" type="text"
                        name="lain_lain" id="lain_lain" value="<?php echo e(old('lain_lain', $gaji ? $gaji->lain_lain : null)); ?>">
                    <?php if($errors->has('lain_lain')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('lain_lain')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="jumlah_lain">Nilai Tunjangan Lain</label>
                    <input class="form-control <?php echo e($errors->has('jumlah_lain') ? 'is-invalid' : ''); ?>" type="number"
                        name="jumlah_lain" id="jumlah_lain" value="<?php echo e(old('jumlah_lain', $gaji ? $gaji->jumlah_lain : null)); ?>">
                    <?php if($errors->has('jumlah_lain')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('jumlah_lain')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-danger" type="submit">
                        <?php echo e(trans('save')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/gajis/create.blade.php ENDPATH**/ ?>