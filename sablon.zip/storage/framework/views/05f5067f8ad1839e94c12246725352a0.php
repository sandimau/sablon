<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Whattodo</h5>
                </div>
                <a href="<?php echo e(route('whattodo.create')); ?>" class="btn btn-primary ">Add Whattodo</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="myTable">
                    <thead>
                        <tr>
                            <th>isi</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $whattodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $what): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-entry-id="<?php echo e($what->id); ?>">
                                <td><?php echo e($what->isi); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('whattodo.edit', $what->id)); ?>" class="btn btn-info btn-sm me-1"><i
                                                class='bx bxs-edit'></i> Edit</a>
                                        <form action="<?php echo e(route('akuns.destroy', $what->id)); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('delete')); ?>

                                            <button type="submit" onclick="return confirm('Are you sure?')"
                                                class="btn btn-danger btn-sm"><i class='bx bxs-trash' ></i> delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/home.blade.php ENDPATH**/ ?>