<?php $__env->startSection('title'); ?>
    Kategori List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Kategoris</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your Kategoris here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akun_create')): ?>
                        <a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary ">Add Kategori</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nama</th>
                                <th scope="col">actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($kategori->id); ?></td>
                                    <td><a href="<?php echo e(route('produks.index', $kategori->id)); ?>"><?php echo e($kategori->nama); ?></a></td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('kategori.edit', $kategori->id)); ?>" class="btn btn-info btn-sm me-1"><i
                                                    class='bx bxs-edit'></i> Edit</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/kategoris/index.blade.php ENDPATH**/ ?>