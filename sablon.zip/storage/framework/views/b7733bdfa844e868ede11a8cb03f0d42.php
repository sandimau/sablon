<?php $__env->startSection('title'); ?>
    AR List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Ars</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your ars here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ar_create')): ?>
                        <a href="<?php echo e(route('ars.create')); ?>" class="btn btn-primary ">Add ar</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Kode</th>
                                <th scope="col">warna</th>
                                <th scope="col">ttd</th>
                                <th scope="col">actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ar->id); ?></td>
                                    <td><?php echo e($ar->member->nama_lengkap); ?></td>
                                    <td><?php echo e($ar->kode); ?></td>
                                    <td style="background-color: <?php echo e($ar->warna); ?>; color: #fff;">warna</td>
                                    <td>
                                        <?php if($ar->ttd): ?>
                                            <img style="height: 60px" src="<?php echo e(url('uploads/ttd/' . $ar->ttd)); ?>"
                                                alt="" srcset="">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('ars.edit', $ar->id)); ?>" class="btn btn-info btn-sm me-1"><i
                                                    class='bx bxs-edit'></i> Edit</a>
                                            <form action="<?php echo e(route('ars.destroy', $ar->id)); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('delete')); ?>

                                                <button type="submit" onclick="return confirm('Are you sure?')"
                                                    class="btn btn-danger btn-sm"><i class='bx bxs-trash' ></i> delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/ars/index.blade.php ENDPATH**/ ?>