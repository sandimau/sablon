<?php $__env->startSection('title'); ?>
    Produksi List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Produksis</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your produksis here.</h6>
                    </div>
                    <a href="<?php echo e(route('produksis.create')); ?>" class="btn btn-primary">Add produksis</a>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">Nama</th>
                                <th scope="col">Warna</th>
                                <th scope="col">Grup</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($produksi->nama); ?></td>
                                    <td><?php echo e($produksi->warna); ?></td>
                                    <td><?php echo e($produksi->grup); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('produksis.edit', $produksi->id)); ?>"
                                                class="btn btn-info btn-sm me-1"><i class='bx bxs-edit'></i> Edit</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/produksis/index.blade.php ENDPATH**/ ?>