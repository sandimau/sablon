<?php $__env->startSection('title'); ?>
    Data Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Members</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your members here.</h6>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>
                                    nama lengkap
                                </th>
                                <th>
                                    tgl masuk
                                </th>
                                <th>
                                    tgl keluar
                                </th>
                                <th>
                                    tgl lahir
                                </th>
                                <th>
                                    tempat lahir
                                </th>
                                <th>
                                    alamat
                                </th>
                                <th>
                                    hp
                                </th>
                                <th>
                                    umur
                                </th>
                                <th>
                                    lama kerja
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($member->id); ?>">
                                    <td>
                                        <a href="<?php echo e(route('members.show', $member->id)); ?>"><?php echo e($member->nama_lengkap ?? ''); ?></a>
                                    </td>
                                    <td><?php echo e($member->tgl_masuk); ?></td>
                                    <td><?php echo e($member->tgl_keluar); ?></td>
                                    <td><?php echo e($member->tgl_lahir); ?></td>
                                    <td><?php echo e($member->tempat_lahir); ?></td>
                                    <td><?php echo e($member->alamat); ?></td>
                                    <td><?php echo e($member->no_telp); ?></td>
                                    <td><?php echo e($member->umur ?? ''); ?></td>
                                    <td><?php echo e($member->lamaKerja ?? ''); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/members/nonaktif.blade.php ENDPATH**/ ?>