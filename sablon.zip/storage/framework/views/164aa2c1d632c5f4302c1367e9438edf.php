<?php $__env->startSection('title'); ?>
    Create Whattodos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">add whattodo</h5>
                </div>
                <a href="<?php echo e(route('whattodo')); ?>" class="btn btn-success ">back</a>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('whattodo.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group ">
                    <label for="isi" class="mb-3">tugas</label>
                    <input class="form-control <?php echo e($errors->has('isi') ? 'is-invalid' : ''); ?>" type="text" name="isi"
                        id="isi" value="<?php echo e(old('isi', '')); ?>">
                    <?php if($errors->has('isi')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('isi')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/whattodos/create.blade.php ENDPATH**/ ?>