<?php $__env->startSection('title'); ?>
    Akun Details | buku besar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Kas</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your kas here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akun_kategori_create')): ?>
                        <a href="<?php echo e(route('akundetail.transfer',$akunDetail->id)); ?>" class="btn btn-primary ">transfer</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <table class="table table-striped" id="myTable">
                    <thead>
                        <tr>
                            <th scope="col">tanggal</th>
                            <th scope="col">ket</th>
                            <th scope="col">debet</th>
                            <th scope="col">kredit</th>
                            <th scope="col">saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bukubesars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bukubesar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bukubesar->tangal); ?></td>
                                <td><?php echo e($bukubesar->ket); ?></td>
                                <td><?php echo e($bukubesar->debet); ?></td>
                                <td><?php echo e($bukubesar->kredit); ?></td>
                                <td><?php echo e($bukubesar->saldo); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/bukubesars/index.blade.php ENDPATH**/ ?>