<?php $__env->startSection('title'); ?>
    Data Kontaks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Kontaks</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your kontaks here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kontak_create')): ?>
                        <a href="<?php echo e(route('kontaks.create')); ?>" class="btn btn-primary">Add kontaks</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">perusahaan</th>
                                <th scope="col">kontak</th>
                                <th scope="col">No Telp</th>
                                <th scope="col">Lama Gabung(bln)</th>
                                <th scope="col">Order Terakhir(bln)</th>
                                <th scope="col">Total Omzet</th>
                                <th scope="col">Omzet/Bln</th>
                                <th scope="col">Jenis</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kontaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('kontaks.show',$kontak->id)); ?>"><?php echo e($kontak->nama); ?></a></td>
                                    <td><?php echo e($kontak->kontak); ?></td>
                                    <td><?php echo e($kontak->noTelp); ?></td>
                                    <td><?php echo e($kontak->bergabung); ?></td>
                                    <td><?php echo e($kontak->lastOrder); ?></td>
                                    <td><?php echo e(number_format($kontak->allOmzet)); ?></td>
                                    <td><?php echo e(number_format($kontak->monthOmzet)); ?></td>
                                    <td><?php echo html_entity_decode($kontak->jenis); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/kontaks/index.blade.php ENDPATH**/ ?>