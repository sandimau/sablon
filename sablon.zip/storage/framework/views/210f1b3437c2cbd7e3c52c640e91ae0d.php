<?php $__env->startSection('title'); ?>
Create Kategoris
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            create kategori
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('kategori.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="nama">nama</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama"
                        id="nama" value="<?php echo e(old('nama', '')); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>

                </div>
                <div class="form-group">
                    <button class="btn btn-danger" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/kategoris/create.blade.php ENDPATH**/ ?>