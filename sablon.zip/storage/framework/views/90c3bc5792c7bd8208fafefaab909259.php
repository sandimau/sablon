<?php $__env->startSection('title'); ?>
    Detail Sistems
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Sistems</h5>
                    <h6 class="card-subtitle mb-2 text-muted">Manage your sistems here.</h6>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sistem_create')): ?>
                    <a href="<?php echo e(route('sistem.create')); ?>" class="btn btn-primary">Add sistems</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <div class="form-group">
                    <a class="btn btn-success text-white mb-3" href="<?php echo e(route('sistem.edit')); ?>">
                        edit
                    </a>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <?php $__currentLoopData = $sistems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th>
                                        <?php echo e($item->nama); ?>

                                    </th>
                                    <td>
                                        <?php if($item->type == 'text'): ?>
                                            <?php echo e($item->isi); ?>

                                        <?php endif; ?>
                                        <?php if($item->type == 'file'): ?>
                                            <img src="<?php echo e(url('uploads/'.$item->nama.'/' . $item->isi)); ?>"
                                                alt="" srcset="">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/sistems/index.blade.php ENDPATH**/ ?>