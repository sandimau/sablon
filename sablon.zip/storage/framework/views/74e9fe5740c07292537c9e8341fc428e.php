<?php $__env->startSection('title'); ?>
    Belanja Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="mt-2">
            <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Belanjas</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your belanja here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member_create')): ?>
                        <a href="<?php echo e(route('belanja.create')); ?>" class="btn btn-primary"><i class='bx bx-plus-circle'></i> Add</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-4">
                      <div class="border-start border-start-4 border-start-info px-3 mb-3"><small class="text-medium-emphasis">supplier</small>
                        <div class="fs-5 fw-semibold"><?php echo e($belanja->kontak->nama); ?></div>
                      </div>
                    </div>
                    <!-- /.col-->
                    <div class="col-4">
                      <div class="border-start border-start-4 border-start-info px-3 mb-3"><small class="text-medium-emphasis">diskon</small>
                        <div class="fs-5 fw-semibold"><?php echo e($belanja->diskon); ?></div>
                      </div>
                    </div>
                    <!-- /.col-->
                    <div class="col-4">
                        <div class="border-start border-start-4 border-start-info px-3 mb-3"><small class="text-medium-emphasis">total belanja</small>
                          <div class="fs-5 fw-semibold"><?php echo e(number_format($belanja->total, 0, ',', '.')); ?></div>
                        </div>
                      </div>
                      <!-- /.col-->
                  </div>
                <div class="table-responsive">
                    <table class=" table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>produk</th>
                                <th>keterangan</th>
                                <th>satuan</th>
                                <th>jumlah</th>
                                <th>harga</th>
                                <th>total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $belanjaDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $belanja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($belanja->id); ?>">
                                    <td><?php echo e($belanja->produk->nama); ?></td>
                                    <td><?php echo e($belanja->keterangan); ?></td>
                                    <td><?php echo e($belanja->produk->satuan); ?></td>
                                    <td><?php echo e(number_format($belanja->jumlah, 0, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($belanja->harga, 0, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($belanja->harga * $belanja->jumlah, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/belanjas/detail.blade.php ENDPATH**/ ?>