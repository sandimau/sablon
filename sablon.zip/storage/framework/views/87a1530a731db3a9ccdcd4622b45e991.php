<?php $__env->startSection('title'); ?>
    Speks List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Speks</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your speks here.</h6>
                    </div>
                    <a href="<?php echo e(route('speks.create')); ?>" class="btn btn-primary">Add speks</a>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">Nama</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $speks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($spek->nama); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('speks.edit', $spek->id)); ?>"
                                                class="btn btn-info btn-sm me-1"><i class='bx bxs-edit'></i> Edit</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/speks/index.blade.php ENDPATH**/ ?>