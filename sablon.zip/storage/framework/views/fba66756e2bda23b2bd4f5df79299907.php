<?php $__env->startSection('title'); ?>
Create Cuti
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5>Add Cuti</h5>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("cuti.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="member_id" value="<?php echo e($members->id); ?>">
            <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input class="form-control date <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" type="date" name="tanggal" id="tanggal" value="<?php echo e(old('tanggal')); ?>">
                <?php if($errors->has('tanggal')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tanggal')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="keterangan">keterangan</label>
                <textarea class="form-control <?php echo e($errors->has('keterangan') ? 'is-invalid' : ''); ?>" name="keterangan" id="" cols="30" rows="10">
                    <?php echo e(old('keterangan', '')); ?>

                </textarea>
                <?php if($errors->has('keterangan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('keterangan')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>cuti/ijin</label>
                <select class="form-control" name="cuti" name="cuti">
                    <option>pilih cuti/ijin</option>
                    <option value="1">cuti</option>
                    <option value="0">ijin</option>
                </select>
                <?php if($errors->has('cuti')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cuti')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button class="btn btn-primary mt-4" type="submit">
                    save
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/members/cuti.blade.php ENDPATH**/ ?>