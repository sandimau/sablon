<?php $__env->startSection('title'); ?>
Create lembur
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5>Edit lembur</h5>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("lembur.update", [$lembur->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="member_id" value="<?php echo e($lembur->member()->first()->id); ?>">
                <div class="form-group">
                    <label for="bulan">bulan</label>
                    <select class="form-control" name="bulan" name="bulan">
                        <option>pilih bulan</option>
                        <?php $__currentLoopData = $bulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($lembur->bulan === $bulan ? 'selected' : ''); ?> value="<?php echo e($key); ?>"><?php echo e($bulan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('bulan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('bulan')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="jam">jam</label>
                    <input type="number" class="form-control" name="jam" value="<?php echo e(old('jam',$lembur->jam)); ?>" >
                    <?php if($errors->has('jam')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('jam')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="keterangan">keterangan</label>
                    <textarea class="form-control <?php echo e($errors->has('keterangan') ? 'is-invalid' : ''); ?>" name="keterangan" id=""
                        cols="30" rows="10"><?php echo e(old('keterangan',$lembur->keterangan)); ?></textarea>
                    <?php if($errors->has('keterangan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('keterangan')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/lemburs/edit.blade.php ENDPATH**/ ?>