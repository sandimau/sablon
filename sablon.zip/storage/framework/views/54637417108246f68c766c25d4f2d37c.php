<?php $__env->startSection('title'); ?>
    SLip Gaji
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-body printableArea m-b-0">
                <div class="row">
                    <div class="col-7">
                        <h4 class="m-b-0">kepada: <br> <?php echo e($penggajian->member->nama_lengkap); ?> </h4>
                        <p class="text-muted m-t-0"><?php echo e($penggajian->member->alamat); ?></p>
                    </div>
                    <div class="col-5">
                        <b>bulan : <?php echo e($penggajian->bulan); ?></b>
                        <br> <i class="fa fa-calendar"></i> <?php echo e(date_format($penggajian->created_at, 'd-m-Y')); ?>

                    </div>
                    <div class="col-md-12">
                        <div class="table-responsive" style="clear: both;">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Jenis</th>
                                        <th style="width: 500px" class="text-right">Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Gaji Pokok</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->pokok, 0, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan Lama Kerja</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->lama_kerja, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan Bagian</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->bagian, 0, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan Performance</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->performance, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan transportasi</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->transportasi, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan komunikasi</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->komunikasi, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan Kehadiran</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->kehadiran, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan lainnya</td>
                                        <td class="text-right"><?php echo e($penggajian->lain_lain); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan Jumlah lainnya</td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->jumlah_lain, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tunjangan lembur <?php echo e(number_format($penggajian->jam_lembur, 0, ',', '.')); ?></td>
                                        <td class="text-right"><?php echo e(number_format($penggajian->lembur, 0, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kasbon</td>
                                        <td class="text-right inline-block">
                                            <?php echo e(number_format($penggajian->kasbon, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <hr>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-2" style="font-weight: 400">
                            hormat kami
                        </div>
                        <div class="mt-5" style="font-weight: 400">
                            (_____________)
                        </div>
                    </div>
                    <div class="col-6">
                        <h5>Total: <?php echo e(number_format($penggajian->total, 0, ',', '.')); ?></h5>
                    </div>
                </div>
            </div>
            <div class="mt-4">
                <button id="print" class="btn btn-primary m-t-15" type="button"> <span><i class="fa fa-print"></i>
                        Print</span> </button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script src="<?php echo e(asset('js/jquery.PrintArea.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $("#print").click(function() {
                var mode = 'iframe'; //popup
                var close = mode == "popup";
                var options = {
                    mode: mode,
                    popClose: close
                };
                $("div.printableArea").printArea(options);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/penggajians/slip.blade.php ENDPATH**/ ?>