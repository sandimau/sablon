<?php $__env->startSection('title'); ?>
    Bayar Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">add bayar</h5>
                </div>
                <a href="<?php echo e(route('order.dashboard')); ?>" class="btn btn-success ">back</a>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('order.storeBayar')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                <div class="form-group mb-3">
                    <label for="tema">konsumen</label>
                    <input class="form-control" type="text" value="<?php echo e($order->kontak->nama); ?>" disabled>
                </div>
                <div class="form-group mb-3">
                    <label for="tema">total tagihan</label>
                    <input id="total" class="form-control" type="text" value="<?php echo e($order->total); ?>" disabled>
                </div>
                <div class="form-group mb-3">
                    <label for="tema">pembayaran</label>
                    <input id="pembayaran" class="form-control" type="text" value="<?php echo e($order->bayar); ?>" disabled>
                </div>
                <div class="form-group mb-3">
                    <label for="tema">kekurangan</label>
                    <input id="kekurangan" class="form-control" type="text" value="<?php echo e($order->kekurangan); ?>" disabled>
                </div>
                <div class="form-group mb-3">
                    <label for="diskon">diskon</label>
                    <input id="diskon" onchange="updateSubTotal()" class="form-control <?php echo e($errors->has('diskon') ? 'is-invalid' : ''); ?>" type="number"
                        name="diskon" id="diskon">
                    <?php if($errors->has('diskon')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('diskon')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="jumlah">Jumlah</label>
                    <input id="jumlah" class="form-control <?php echo e($errors->has('jumlah') ? 'is-invalid' : ''); ?>" type="number"
                        name="jumlah" id="jumlah" value="<?php echo e($order->kekurangan); ?>">
                    <?php if($errors->has('jumlah')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('jumlah')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="akun_detail_id">kas</label>
                    <select class="form-select <?php echo e($errors->has('akun_detail_id') ? 'is-invalid' : ''); ?>"
                        aria-label="Default select example" name="akun_detail_id" id="akun_detail_id">
                        <option >-- pilih kas --</option>
                        <?php $__currentLoopData = $kas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>"><?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('akun_detail_id')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('akun_detail_id')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="tanggal">tanggal</label>
                    <input class="form-control <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" type="date"
                        name="tanggal" id="tanggal" value="<?php echo e(old('tanggal', '')); ?>">
                    <?php if($errors->has('tanggal')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('tanggal')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="ket">ket</label>
                    <input id="ket" class="form-control" type="text"
                        name="ket" id="ket">
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        function updateSubTotal() {
            let total = document.getElementById('total');
            let diskon = document.getElementById('diskon');
            let jumlah = document.getElementById('jumlah');
            let kekurangan = document.getElementById('kekurangan');
            let pembayaran = document.getElementById('pembayaran');
            total.value = <?php echo $order->total + $order->diskon ?> - diskon.value;
            kekurangan.value = jumlah.value = total.value  - pembayaran.value;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orders/bayar.blade.php ENDPATH**/ ?>