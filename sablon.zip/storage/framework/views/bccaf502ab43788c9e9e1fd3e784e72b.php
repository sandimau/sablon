<?php $__env->startSection('title'); ?>
    Create Sistems
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5>Add Sistem</h5>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('sistem.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="nama">Nama</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama"
                        id="nama" value="<?php echo e(old('nama', '')); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="type">Type</label>
                    <select class="form-select <?php echo e($errors->has('type') ? 'is-invalid' : ''); ?>"
                        aria-label="Default select example" name="type" id="type">
                        <option value="text" <?php echo e(old('type', '')); ?>>text</option>
                        <option value="file" <?php echo e(old('type', '')); ?>>file</option>
                        <option value="number" <?php echo e(old('type', '')); ?>>number</option>
                    </select>
                    <?php if($errors->has('type')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('type')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/sistems/create.blade.php ENDPATH**/ ?>