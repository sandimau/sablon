<?php $__env->startSection('title'); ?>
    Create Level
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">add Level</h5>
                </div>
                <a href="<?php echo e(route('level.index')); ?>" class="btn btn-primary ">back</a>
            </div>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('level.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="nama">Nama</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text"
                        name="nama" id="nama" value="<?php echo e(old('nama')); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="gaji_pokok">Gaji Pokok</label>
                    <input class="form-control <?php echo e($errors->has('gaji_pokok') ? 'is-invalid' : ''); ?>" type="number"
                        name="gaji_pokok" id="gaji_pokok" value="<?php echo e(old('gaji_pokok')); ?>">
                    <?php if($errors->has('gaji_pokok')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('gaji_pokok')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="komunikasi">Komunikasi</label>
                    <input class="form-control <?php echo e($errors->has('komunikasi') ? 'is-invalid' : ''); ?>" type="number"
                        name="komunikasi" id="komunikasi" value="<?php echo e(old('komunikasi')); ?>">
                    <?php if($errors->has('komunikasi')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('komunikasi')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="transportasi">Transportasi</label>
                    <input class="form-control <?php echo e($errors->has('transportasi') ? 'is-invalid' : ''); ?>" type="number"
                        name="transportasi" id="transportasi" value="<?php echo e(old('transportasi')); ?>">
                    <?php if($errors->has('transportasi')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('transportasi')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="kehadiran">Kehadiran</label>
                    <input class="form-control <?php echo e($errors->has('kehadiran') ? 'is-invalid' : ''); ?>" type="number"
                        name="kehadiran" id="kehadiran" value="<?php echo e(old('kehadiran')); ?>">
                    <?php if($errors->has('kehadiran')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('kehadiran')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="lama_kerja">Lama Kerja</label>
                    <input class="form-control <?php echo e($errors->has('lama_kerja') ? 'is-invalid' : ''); ?>" type="number"
                        name="lama_kerja" id="lama_kerja" value="<?php echo e(old('lama_kerja')); ?>">
                    <?php if($errors->has('lama_kerja')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('lama_kerja')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/levels/create.blade.php ENDPATH**/ ?>