<?php $__env->startSection('title'); ?>
    Create Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">add order</h5>
                </div>
                <a href="<?php echo e(route('order.dashboard')); ?>" class="btn btn-success ">back</a>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('orderDetail.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                <div class="form-group mb-3">
                    <label for="nama" class="mb-2">Produk</label>
                    <div id="autocompleteProduk" class="autocomplete">
                        <input class="autocomplete-input produk <?php echo e($errors->has('produk_id') ? 'invalid' : ''); ?>"
                            placeholder="cari produk" aria-label="cari produk">
                        <span id="closeBrgProduk"></span>
                        <ul class="autocomplete-result-list"></ul>
                        <input type="hidden" id="produkId" name="produk_id">
                    </div>
                    <?php if($errors->has('produk_id')): ?>
                        <div class="invalid-feedback z-10">
                            <?php echo e($errors->first('produk_id')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="tema">Tema</label>
                    <input class="form-control <?php echo e($errors->has('tema') ? 'is-invalid' : ''); ?>" type="text" name="tema"
                        id="tema" value="<?php echo e(old('tema', '')); ?>">
                    <?php if($errors->has('tema')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('tema')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="jumlah">Jumlah</label>
                    <input class="form-control <?php echo e($errors->has('jumlah') ? 'is-invalid' : ''); ?>" type="number"
                        name="jumlah" id="jumlah" value="<?php echo e(old('jumlah', '')); ?>">
                    <?php if($errors->has('jumlah')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('jumlah')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="harga">Harga</label>
                    <input class="form-control <?php echo e($errors->has('harga') ? 'is-invalid' : ''); ?>" type="number"
                        name="harga" id="harga" value="<?php echo e(old('harga', '')); ?>">
                    <?php if($errors->has('harga')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('harga')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <?php $__currentLoopData = $speks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group mb-3">
                        <label for="spek"><?php echo e($item->nama); ?></label>
                        <input class="form-control" type="text"
                            name="<?php echo e($item->nama); ?>" id="spek" >
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group mb-3">
                    <label for="keterangan">Keterangan</label>
                    <textarea class="form-control <?php echo e($errors->has('keterangan') ? 'is-invalid' : ''); ?>" name="keterangan" id=""
                        cols="30" rows="10"><?php echo e(old('keterangan', '')); ?></textarea>
                    <?php if($errors->has('keterangan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('keterangan')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="deathline">Deathline</label>
                    <input class="form-control <?php echo e($errors->has('deathline') ? 'is-invalid' : ''); ?>" type="date"
                        name="deathline" id="deathline" value="<?php echo e(old('keterangan', '')); ?>">
                    <?php if($errors->has('deathline')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('deathline')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src="https://unpkg.com/@trevoreyre/autocomplete-js"></script>
    <link rel="stylesheet" href="https://unpkg.com/@trevoreyre/autocomplete-js/dist/style.css" />
    <script>
        new Autocomplete('#autocompleteProduk', {
            search: input => {
                const url = "<?php echo e(url('admin/produk/api?q=')); ?>" + `${escape(input)}`;
                return new Promise(resolve => {
                    if (input.length < 1) {
                        return resolve([])
                    }

                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            resolve(data);
                        })
                })
            },
            getResultValue: result => result.nama,
            onSubmit: result => {
                let idProduk = document.getElementById('produkId');
                idProduk.value = result.id;

                let btn = document.getElementById("closeBrgProduk");
                btn.style.display = "block";
                btn.innerHTML =
                    `<button onclick="clearProduk()" type="button" class="btnClose btn-warning"><i class='bx bx-x-circle' ></i></button>`;
            },
        })

        function clearData() {
            let btn = document.getElementById("closeBrg");
            btn.style.display = "none";
            let auto = document.querySelector(".autocomplete-input");
            auto.value = null;
            let idProduk = document.getElementById('kontakId');
            idProduk.value = null;
        }

        function clearProduk() {
            let btn = document.getElementById("closeBrgProduk");
            btn.style.display = "none";
            let auto = document.querySelector(".autocomplete-input.produk");
            auto.value = null;
            let idProduk = document.getElementById('produkId');
            idProduk.value = null;
        }
    </script>
    <style>
        #autocomplete,
        #autocompleteProduk {
            max-width: 600px;
        }

        #closeBrg,
        #closeBrgProduk {
            position: relative;
        }

        #closeBrg button,
        #closeBrgProduk button {
            position: absolute;
            right: -15px;
            top: -40px;
        }

        .btnClose {
            padding: 4px 8px;
            border: 0;
            border-radius: 50px;
            background: #fdc54c;
        }

        .autocomplete-input.is-invalid,
        .autocomplete-input.invalid {
            border: solid 1px red;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orderDetails/create.blade.php ENDPATH**/ ?>