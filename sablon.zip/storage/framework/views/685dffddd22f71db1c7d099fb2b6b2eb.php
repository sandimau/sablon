<?php $__env->startSection('title'); ?>
Edit Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        edit members
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("members.update", [$member->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap</label>
                <input class="form-control <?php echo e($errors->has('nama_lengkap') ? 'is-invalid' : ''); ?>" type="text" name="nama_lengkap" id="nama_lengkap" value="<?php echo e(old('nama_lengkap',$member->nama_lengkap)); ?>">
                <?php if($errors->has('nama_lengkap')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama_lengkap')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="tgl_masuk">Tanggal Masuk</label>
                <input class="form-control date <?php echo e($errors->has('tgl_masuk') ? 'is-invalid' : ''); ?>" type="date" name="tgl_masuk" id="tgl_masuk" value="<?php echo e(old('tgl_masuk', $member->tgl_masuk)); ?>">
                <?php if($errors->has('tgl_masuk')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tgl_masuk')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="tgl_lahir">Tanggal Lahir</label>
                <input class="form-control date <?php echo e($errors->has('tgl_lahir') ? 'is-invalid' : ''); ?>" type="date" name="tgl_lahir" id="tgl_lahir" value="<?php echo e(old('tgl_lahir', $member->tgl_lahir)); ?>">
                <?php if($errors->has('tgl_lahir')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tgl_lahir')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="tempat_lahir">Tempat Lahir</label>
                <input class="form-control <?php echo e($errors->has('tempat_lahir') ? 'is-invalid' : ''); ?>" type="text" name="tempat_lahir" id="tempat_lahir" value="<?php echo e(old('tempat_lahir',$member->tempat_lahir)); ?>">
                <?php if($errors->has('tempat_lahir')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tempat_lahir')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <textarea class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid' : ''); ?>" name="alamat" id="" cols="30" rows="10"><?php echo e(old('alamat',$member->nama_lengkap)); ?></textarea>
                <?php if($errors->has('alamat')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('alamat')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="no_telp">No Telp</label>
                <input class="form-control <?php echo e($errors->has('no_telp') ? 'is-invalid' : ''); ?>" type="text" name="no_telp" id="no_telp" value="<?php echo e(old('no_telp',$member->no_telp)); ?>">
                <?php if($errors->has('no_telp')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('no_telp')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="tgl_gajian">Tanggal Gajian</label>
                <select class="form-select" name="tgl_gajian" name="tgl_gajian">
                    <option>pilih tanggal</option>
                    <?php $__currentLoopData = $tglGaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($key); ?> <?php echo e($key == $member->tgl_gajian ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('tgl_gajian')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tgl_gajian')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="no_rek">No Rek</label>
                <input class="form-control <?php echo e($errors->has('no_rek') ? 'is-invalid' : ''); ?>" type="text" name="no_rek" id="no_rek" value="<?php echo e(old('no_rek',$member->no_rek)); ?>">
                <?php if($errors->has('no_rek')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('no_rek')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>status</label>
                <select class="form-select" name="status" name="status">
                    <option>pilih status</option>
                    <option value="1" <?php echo e($member->status == "1" ? 'selected' : ''); ?>>aktif</option>
                    <option value="0" <?php echo e($member->status == "0" ? 'selected' : ''); ?>>tidak aktif</option>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button class="btn btn-danger mt-3" type="submit">
                    save
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/members/edit.blade.php ENDPATH**/ ?>