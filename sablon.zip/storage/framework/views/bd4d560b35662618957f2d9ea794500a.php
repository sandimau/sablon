<?php $__env->startSection('title'); ?>
    Data Produks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Produks</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your produks here.</h6>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk_create')): ?>
                        <a href="<?php echo e(route('produks.create', $kategori->id)); ?>" class="btn btn-primary"><i
                                class='bx bx-plus-circle'></i> Add</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">Gambar</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Satuan</th>
                                <th scope="col">Harga</th>
                                <th scope="col">jual</th>
                                <th scope="col">beli</th>
                                <th scope="col">stok</th>
                                <th scope="col">action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if($produk->gambar): ?>
                                            <a class="test-popup-link"
                                                href="<?php echo e(asset('uploads/produk/' . $produk->gambar)); ?>">
                                                <img style="height: 60px"
                                                    src="<?php echo e(url('uploads/produk/' . $produk->gambar)); ?>" alt=""
                                                    srcset="">
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($produk->nama); ?></td>
                                    <td><?php echo e($produk->satuan); ?></td>
                                    <td><?php echo e($produk->harga); ?></td>
                                    <td>
                                        <?php if($produk->jual == 1): ?>
                                            <i class='bx bxs-check-square'></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($produk->beli == 1): ?>
                                            <i class='bx bxs-check-square'></i>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('produkStok.index', $produk->id)); ?>"><?php echo e($produk->lastStok); ?></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('produks.edit', $produk->id)); ?>"
                                            class="btn btn-info btn-sm me-1"><i class='bx bxs-edit'></i> Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
        $(document).ready(function() {
            $('.test-popup-link').magnificPopup({
                type: 'image'
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/produks/index.blade.php ENDPATH**/ ?>