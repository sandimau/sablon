<?php $__env->startSection('title'); ?>
    Data Omzet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <canvas id="myChart"></canvas>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('myChart');

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [
                    <?php
                        foreach ($orders as $value) {
                            echo $value->year . ',';
                        }
                    ?>
                ],
                datasets: [{
                    label: 'order',
                    data: [
                        <?php
                            foreach ($orders as $value) {
                                echo $value->sum . ',';
                            }
                        ?>
                    ],
                    borderWidth: 1
                }],
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orders/omzet.blade.php ENDPATH**/ ?>