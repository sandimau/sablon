<?php $__env->startSection('title'); ?>
    edit gambar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">edit gambar</h5>
                </div>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('orderDetail.updateGambar', $detail->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('patch'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="order_detail_id" value="<?php echo e($detail->id); ?>">
                <div class="mb-3">
                    <label for="formFile" class="form-label">gambar</label>
                    <input class="form-control" type="file" id="formFile" name="gambar">
                </div>
                <img style="height: 400px" src="<?php echo e(asset('uploads/gambar/' . $detail->gambar)); ?>" alt=""
                    srcset="">
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orderDetails/editGambar.blade.php ENDPATH**/ ?>