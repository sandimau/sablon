<?php $__env->startSection('title'); ?>
    Data Omzet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <canvas id="speedChart"></canvas>
        </div>
    </div>
    <?php ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var speedCanvas = document.getElementById("speedChart");

        var dataFirst = {
            label: <?php
                $data = null;
                if ($last->first()) {
                    $data = $last->first()->year;
                }
            echo '"omzet ' . $data . '"'; ?>,
            data: [
                <?php
                    foreach ($last as $value) {
                        echo $value->omzet . ',';
                    }
                ?>
            ],
            lineTension: 0,
            fill: false,
            borderColor: 'red'
        };

        var dataSecond = {
            label: <?php echo '"omzet '.$years->first()->year . '"' ?>,
            data: [
                <?php
                    foreach ($years as $value) {
                        echo $value->omzet . ',';
                    }
                ?>
            ],
            lineTension: 0,
            fill: false,
            borderColor: 'blue'
        };

        var speedData = {
            labels: [
                <?php
                    foreach ($years as $value) {
                        echo '"' . $value->monthname . '",';
                    }
                ?>
            ],
            datasets: [dataFirst, dataSecond]
        };

        var chartOptions = {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    boxWidth: 80,
                    fontColor: 'black'
                }
            }
        };

        var lineChart = new Chart(speedCanvas, {
            type: 'line',
            data: speedData,
            options: chartOptions
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orders/omzetBulan.blade.php ENDPATH**/ ?>