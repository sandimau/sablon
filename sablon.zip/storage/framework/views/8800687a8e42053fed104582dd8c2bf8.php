<?php $__env->startSection('title'); ?>
    Create Bagian
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">add Bagian</h5>
                </div>
                <a href="<?php echo e(route('bagian.index')); ?>" class="btn btn-primary ">back</a>
            </div>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('bagian.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="nama">Nama</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text"
                        name="nama" id="nama" value="<?php echo e(old('nama')); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="grade">Grade</label>
                    <input class="form-control <?php echo e($errors->has('grade') ? 'is-invalid' : ''); ?>" type="number"
                        name="grade" id="grade" value="<?php echo e(old('grade')); ?>">
                    <?php if($errors->has('grade')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('grade')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/bagians/create.blade.php ENDPATH**/ ?>