<?php $__env->startSection('title'); ?>
    Edit Sistems
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5>Update Sistem</h5>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('sistem.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $sistems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group mb-3">
                    <label for="<?php echo e($item->nama); ?>"><?php echo e($item->nama); ?></label>
                    <input class="form-control <?php echo e($errors->has($item->nama) ? 'is-invalid' : ''); ?>" type="<?php echo e($item->type); ?>" name="<?php echo e($item->nama); ?>"
                        id="<?php echo e($item->nama); ?>" value="<?php echo e($item->isi); ?>">
                    <?php if($errors->has($item->nama)): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first($item->nama)); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/sistems/edit.blade.php ENDPATH**/ ?>