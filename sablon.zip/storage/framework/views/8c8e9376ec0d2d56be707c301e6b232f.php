<?php $__env->startSection('title'); ?>
    Data produk stoks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Produk Stoks > <?php echo e($produk->nama); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your produk stoks here.</h6>
                    </div>
                    <div style="text-align: right">
                        <a href="<?php echo e(route('produks.index', $produk->kategori_id)); ?>" class="btn btn-secondary mb-2">back</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kontak_create')): ?>
                            <a href="<?php echo e(route('produkStok.create', $produk->id)); ?>" class="btn btn-primary mb-2">opname</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">tanggal</th>
                                <th scope="col">keterangan</th>
                                <th scope="col">penambahan</th>
                                <th scope="col">pengurangan</th>
                                <th scope="col">stok akhir</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produkStoks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($stok->tanggal); ?></td>
                                    <td><?php echo e($stok->keterangan); ?></td>
                                    <td><?php echo e(number_format($stok->tambah)); ?></td>
                                    <td><?php echo e(number_format($stok->kurang)); ?></td>
                                    <td><?php echo e(number_format($stok->saldo)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/produkStoks/index.blade.php ENDPATH**/ ?>