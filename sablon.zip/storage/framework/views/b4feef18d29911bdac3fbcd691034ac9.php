<?php $__env->startSection('title'); ?>
    Data Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">orders</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Manage your orders here.</h6>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="mt-2">
                    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php echo e($orders->links()); ?>

                <div class="table-responsive">
                    <table class="table table-striped table-hover" >
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Konsumen</th>
                                <th>Order</th>
                                <th>Total</th>
                                <th>Kekurangan</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($order->id); ?>">
                                    <td><?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></td>
                                    <td><?php echo e($order->kontak->nama ?? ''); ?></td>
                                    <td><a href="<?php echo e(route('order.detail', $order->id)); ?>"><?php echo e($order->listproduk); ?></a></td>
                                    <td><?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($order->kekurangan, 0, ',', '.')); ?></td>
                                    <td>
                                        <?php if($order->bayar == 0 && $order->total > 0): ?>
                                            <a href="<?php echo e(route('order.unpaid')); ?>"
                                                class="btn rounded-pill btn-danger btn-sm text-white">belum bayar</a>
                                        <?php endif; ?>
                                        <?php if($order->bayar == 0 && $order->total == 0): ?>
                                            <a href="<?php echo e(route('order.unpaid')); ?>"
                                                class="btn rounded-pill btn-danger btn-sm text-white">batal</a>
                                        <?php endif; ?>
                                        <?php if($order->total > $order->bayar && $order->bayar > 0): ?>
                                            <a href="<?php echo e(route('order.unpaid')); ?>"
                                                class="btn rounded-pill btn-warning btn-sm text-white">belum lunas</a>
                                        <?php endif; ?>
                                        <?php if($order->total == $order->bayar && $order->bayar != 0  && $order->total != 0): ?>
                                            <button class="btn rounded-pill btn-success btn-sm text-white">lunas</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>