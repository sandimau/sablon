<?php $__env->startSection('title'); ?>
    Create Produk Stoks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Add Produk Stoks > <?php echo e($produk->nama); ?></h5>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kontak_create')): ?>
                    <a href="<?php echo e(route('produkStok.index', $produk->id)); ?>" class="btn btn-secondary">back</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('produkStok.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="produk_id" value="<?php echo e($produk->id); ?>">
                <div class="form-group mb-3">
                    <label for="tambah">tambah</label>
                    <input class="form-control <?php echo e($errors->has('tambah') ? 'is-invalid' : ''); ?>" type="number"
                        name="tambah" id="tambah" value="0">
                    <?php if($errors->has('tambah')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('tambah')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="kurang">kurang</label>
                    <input class="form-control <?php echo e($errors->has('kurang') ? 'is-invalid' : ''); ?>" type="number"
                        name="kurang" id="kurang" value="0">
                    <?php if($errors->has('kurang')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('kurang')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="deskripsi">Keterangan</label>
                    <textarea class="form-control <?php echo e($errors->has('keterangan') ? 'is-invalid' : ''); ?>" name="keterangan" id=""
                        cols="30" rows="10"><?php echo e(old('keterangan', '')); ?></textarea>
                    <?php if($errors->has('keterangan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('keterangan')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="tanggal">tanggal</label>
                    <input class="form-control <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" type="date"
                        name="tanggal" id="tanggal" value="<?php echo e(old('tanggal', '')); ?>">
                    <?php if($errors->has('tanggal')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('tanggal')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/produkStoks/create.blade.php ENDPATH**/ ?>