<?php $__env->startSection('title'); ?>
Edit Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Update role</h5>
            <div class="container mt-4">

                <form method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input value="<?php echo e($role->name); ?>" type="text" class="form-control" name="name" placeholder="Name"
                            required>
                    </div>

                    <label for="permissions" class="form-label">Assign Permissions</label>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <th scope="col" width="1%"><input type="checkbox" name="all_permission"></th>
                                <th scope="col" width="20%">Name</th>
                                <th scope="col" width="1%">Guard</th>
                            </thead>

                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                        value="<?php echo e($permission->name); ?>" class='permission' <?php echo e(in_array($permission->name, $rolePermissions)
                                        ? 'checked'
                                        : ''); ?>>
                                </td>
                                <td><?php echo e($permission->name); ?></td>
                                <td><?php echo e($permission->guard_name); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>

                    <button type="submit" class="btn btn-primary">Save changes</button>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-default">Back</a>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script type="text/javascript">
$(document).ready(function() {
    $('[name="all_permission"]').on('click', function() {

        if ($(this).is(':checked')) {
            $.each($('.permission'), function() {
                $(this).prop('checked', true);
            });
        } else {
            $.each($('.permission'), function() {
                $(this).prop('checked', false);
            });
        }

    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/roles/edit.blade.php ENDPATH**/ ?>