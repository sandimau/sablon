<?php $__env->startSection('title'); ?>
Show User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Show user</h5>

            <div class="container mt-4">
                <div>
                    Name: <?php echo e($user->name); ?>

                </div>
                <div>
                    Email: <?php echo e($user->email); ?>

                </div>
                <div>
                    Username: <?php echo e($user->username); ?>

                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-info">Edit</a>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Back</a>
                </div>
            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/users/show.blade.php ENDPATH**/ ?>