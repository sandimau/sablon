<?php $__env->startSection('title'); ?>
Create Ar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        create ar
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("ars.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="member_id">member</label>
                <select class="form-select <?php echo e($errors->has('member_id') ? 'is-invalid' : ''); ?>" aria-label="Default select example" name="member_id" id="member_id">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('member_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('member_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('member_id')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label class="required" for="kode">kode</label>
                <input class="form-control <?php echo e($errors->has('kode') ? 'is-invalid' : ''); ?>" type="text" name="kode" id="kode" value="<?php echo e(old('kode', '')); ?>" required>
                <?php if($errors->has('kode')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('kode')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label class="required" for="warna">warna</label>
                <input class="form-control <?php echo e($errors->has('warna') ? 'is-invalid' : ''); ?>" type="color" name="warna" id="warna" value="<?php echo e(old('warna', '')); ?>" required>
                <?php if($errors->has('warna')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('warna')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="formFile" class="form-label">ttd</label>
                <input class="form-control" type="file" id="formFile" name="ttd">
            </div>
            <div class="form-group mb-3">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/ars/create.blade.php ENDPATH**/ ?>