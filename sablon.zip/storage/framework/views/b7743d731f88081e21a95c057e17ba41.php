<?php $__env->startSection('title'); ?>
Show Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e(ucfirst($role->name)); ?> Role</h5>

            <div class="container mt-4">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <th scope="col" width="20%">Name</th>
                            <th scope="col" width="1%">Guard</th>
                        </thead>

                        <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($permission->name); ?></td>
                            <td><?php echo e($permission->guard_name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <div class="mt-4">
                    <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-info">Edit</a>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-default">Back</a>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/roles/show.blade.php ENDPATH**/ ?>