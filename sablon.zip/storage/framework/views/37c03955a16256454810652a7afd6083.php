<ul class="sidebar-nav" data-coreui="navigation" data-simplebar>
    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-3d')); ?>"></use>
            </svg>
            Produksi
        </a>
        <ul class="nav-group-items" style="height: 0px;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('order*') ? 'active' : ''); ?>" href="<?php echo e(route('order.dashboard')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-3d')); ?>"></use>
                        </svg>
                        Proses
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('order*') ? 'active' : ''); ?>" href="<?php echo e(route('order.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-3d')); ?>"></use>
                        </svg>
                        Arsip Order
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>

    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-storage')); ?>"></use>
            </svg>
            Data
        </a>
        <ul class="nav-group-items" style="height: 0px;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('kategori*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('kategori.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-basket')); ?>"></use>
                        </svg>
                        <?php echo e(__('Produk')); ?>

                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kontak_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('kontaks*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('kontaks.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('Kontak')); ?>

                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>

    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cash')); ?>"></use>
            </svg>
            Keuangan
        </a>
        <ul class="nav-group-items" style="height: 0px;">
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akun_access')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('akuns*') ? 'active' : ''); ?>" href="<?php echo e(route('akuns.index')); ?>">
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cash')); ?>"></use>
                            </svg>
                            <?php echo e(__('akuns')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akun_kategori_access')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('akunKategoris*') ? 'active' : ''); ?>"
                            href="<?php echo e(route('akunKategoris.index')); ?>">
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cash')); ?>"></use>
                            </svg>
                            <?php echo e(__('akun kategoris')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akun_detail_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('akunDetails*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('akunDetails.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cash')); ?>"></use>
                        </svg>
                        <?php echo e(__('kas')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('akunDetails*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('order.unpaid')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cash')); ?>"></use>
                        </svg>
                        <?php echo e(__('belum lunas')); ?>

                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('belanjas*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('belanja.index')); ?>">
                    <svg class="nav-icon">
                        <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cash')); ?>"></use>
                    </svg>
                    Belanja
                </a>
            </li>
        </ul>
    </li>

    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
            </svg>
            Pegawai
        </a>
        <ul class="nav-group-items" style="height: 0px;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('members*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('members.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('aktif')); ?>

                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('member*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('members.nonaktif')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('non aktif')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('ars*') ? 'active' : ''); ?>" href="<?php echo e(route('ars.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('cs')); ?>

                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>

    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
            </svg>
            Omzet
        </a>
        <ul class="nav-group-items" style="height: 0px;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('omzet_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('order*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('order.omzet')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('Tahunan')); ?>

                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('order*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('order.omzetBulan')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('Bulanan')); ?>

                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>

    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cog')); ?>"></use>
            </svg>
            User Management
        </a>
        <ul class="nav-group-items" style="height: 0px;">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('users*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('Users')); ?>

                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('level_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('levels*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('level.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('Levels')); ?>

                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bagian_access')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('bagians*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('bagian.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-user')); ?>"></use>
                        </svg>
                        <?php echo e(__('Bagians')); ?>

                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
    <li class="nav-group" aria-expanded="false">
        <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
                <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-cog')); ?>"></use>
            </svg>
            Config
        </a>
        <ul class="nav-group-items" style="height: 0px;">
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('roles*') ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-group')); ?>"></use>
                        </svg>
                        <?php echo e(__('Roles')); ?>

                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('permissions*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('permissions.index')); ?>">
                        <svg class="nav-icon">
                            <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-room')); ?>"></use>
                        </svg>
                        <?php echo e(__('Permissions')); ?>

                    </a>
                </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('produksis*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('produksis.index')); ?>">
                    <svg class="nav-icon">
                        <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-room')); ?>"></use>
                    </svg>
                    <?php echo e(__('Setup Produksi')); ?>

                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('speks*') ? 'active' : ''); ?>" href="<?php echo e(route('speks.index')); ?>">
                    <svg class="nav-icon">
                        <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-room')); ?>"></use>
                    </svg>
                    <?php echo e(__('Spek Produk')); ?>

                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('sistems*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('sistem.index')); ?>">
                    <svg class="nav-icon">
                        <use xlink:href="<?php echo e(asset('icons/coreui.svg#cil-room')); ?>"></use>
                    </svg>
                    <?php echo e(__('Sistem')); ?>

                </a>
            </li>
        </ul>
    </li>
</ul>
<?php /**PATH C:\laragon\www\sablon\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>