<?php $__env->startSection('title'); ?>
    Edit Produks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5>Edit Produk</h5>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('produks.update', [$produk->id])); ?>" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="formFile" class="form-label">gambar</label>
                    <input class="form-control" type="file" id="formFile" name="gambar">
                </div>
                <div class="form-group mb-3">
                    <label for="nama">Nama</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama"
                        id="nama" value="<?php echo e(old('nama', $produk->nama)); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="harga">Harga</label>
                    <input class="form-control <?php echo e($errors->has('harga') ? 'is-invalid' : ''); ?>" type="number"
                        name="harga" id="harga" value="<?php echo e(old('harga', $produk->harga)); ?>">
                    <?php if($errors->has('harga')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('harga')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <div class="form-check">
                        <input name="jual" class="form-check-input <?php echo e($errors->has('jual') ? 'is-invalid' : ''); ?>"
                            type="checkbox" value="1" id="flexCheckDefault" <?php echo e($produk->jual ? 'checked' : null); ?>>
                        <label class="form-check-label" for="flexCheckDefault">
                            Jual
                        </label>
                        <?php if($errors->has('jual')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('jual')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-check">
                        <input name="beli" class="form-check-input <?php echo e($errors->has('beli') ? 'is-invalid' : ''); ?>" type="checkbox" value="1" id="flexCheckChecked"
                            <?php echo e($produk->beli ? 'checked' : null); ?>>
                        <label class="form-check-label" for="flexCheckChecked">
                            beli
                        </label>
                        <?php if($errors->has('beli')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('beli')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-check">
                        <input name="stok" class="form-check-input <?php echo e($errors->has('stok') ? 'is-invalid' : ''); ?>" type="checkbox" value="1" id="flexCheckChecked"
                            <?php echo e($produk->stok ? 'checked' : null); ?>>
                        <label class="form-check-label" for="flexCheckChecked">
                            stok
                        </label>
                        <?php if($errors->has('stok')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('stok')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="satuan">satuan</label>
                    <select class="form-select <?php echo e($errors->has('satuan') ? 'is-invalid' : ''); ?>" aria-label="Default select example" name="satuan"
                        id="satuan">
                        <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e($produk->satuan === $id ? 'selected' : ''); ?>>
                                <?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('satuan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('satuan')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea class="form-control <?php echo e($errors->has('deskripsi') ? 'is-invalid' : ''); ?>" name="deskripsi" id=""
                        cols="30" rows="10"><?php echo e(old('deskripsi', $produk->deskripsi)); ?></textarea>
                    <?php if($errors->has('deskripsi')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('deskripsi')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/produks/edit.blade.php ENDPATH**/ ?>