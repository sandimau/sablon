<?php $__env->startSection('title'); ?>
Kas Pemasukan Lain
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        Kas Pemasukan Lain-Lain
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("transferLain.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($akunDetail->id); ?>" name="akun_detail_id">
            <div class="form-group mb-3">
                <label class="required" for="jumlah">jumlah</label>
                <input class="form-control <?php echo e($errors->has('jumlah') ? 'is-invalid' : ''); ?>" type="number" name="jumlah" id="jumlah" value="<?php echo e(old('jumlah')); ?>">
                <?php if($errors->has('jumlah')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jumlah')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label class="required" for="keterangan">keterangan</label>
                <input class="form-control <?php echo e($errors->has('keterangan') ? 'is-invalid' : ''); ?>" type="text" name="keterangan" id="keterangan" value="<?php echo e(old('keterangan')); ?>">
                <?php if($errors->has('keterangan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('keterangan')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/akundetails/transferLain.blade.php ENDPATH**/ ?>