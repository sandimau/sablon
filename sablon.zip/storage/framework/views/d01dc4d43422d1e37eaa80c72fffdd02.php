<?php $__env->startSection('title'); ?>
    Create Kontaks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5>Add Kontak</h5>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('kontaks.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="nama">Perusahaan</label>
                    <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama"
                        id="nama" value="<?php echo e(old('nama', '')); ?>">
                    <?php if($errors->has('nama')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="kontak">Kontak Person</label>
                    <input class="form-control <?php echo e($errors->has('kontak') ? 'is-invalid' : ''); ?>" type="text" name="kontak"
                        id="kontak" value="<?php echo e(old('kontak', '')); ?>">
                    <?php if($errors->has('kontak')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('kontak')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="noTelp">No Telp</label>
                    <input class="form-control <?php echo e($errors->has('noTelp') ? 'is-invalid' : ''); ?>" type="text" name="noTelp"
                        id="noTelp" value="<?php echo e(old('noTelp', '')); ?>">
                    <?php if($errors->has('noTelp')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('noTelp')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="email">Email</label>
                    <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email"
                        id="email" value="<?php echo e(old('email', '')); ?>">
                    <?php if($errors->has('email')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <div class="form-check">
                        <input name="konsumen" class="form-check-input <?php echo e($errors->has('konsumen') ? 'is-invalid' : ''); ?>" type="checkbox" value="1" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Konsumen
                        </label>
                        <?php if($errors->has('konsumen')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('konsumen')); ?>

                        </div>
                    <?php endif; ?>
                    </div>
                    <div class="form-check">
                        <input name="supplier" class="form-check-input" type="checkbox" value="1" id="flexCheckChecked">
                        <label class="form-check-label" for="flexCheckChecked">
                            Supplier
                        </label>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="alamat">Alamat</label>
                    <textarea class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid' : ''); ?>" name="alamat" id=""
                        cols="30" rows="10"><?php echo e(old('alamat', '')); ?></textarea>
                    <?php if($errors->has('alamat')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('alamat')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="ar_id">cs</label>
                    <select class="form-select <?php echo e($errors->has('ar_id') ? 'is-invalid' : ''); ?>" aria-label="Default select example" name="ar_id" id="ar_id">
                        <option > -- pilih -- cs</option>
                        <?php $__currentLoopData = $ars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($entry->id); ?>" <?php echo e(old('ar_id') == $entry->id ? 'selected' : ''); ?>><?php echo e($entry->member->nama_lengkap); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('ar_id')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('ar_id')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary mt-4" type="submit">
                        save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/kontaks/create.blade.php ENDPATH**/ ?>