<?php $__env->startSection('title'); ?>
    Akun Details | buku besar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light rounded">
        <div class="mt-2">
            <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-lg-6">
                        <h5 class="card-title"><a href="<?php echo e(route('akunDetails.index')); ?>">Kas <?php echo e($akunDetail->nama); ?></a> > Buku Besar</h5>
                    </div>
                    <div style="text-align: right" class="col-lg-6">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akun_kategori_create')): ?>
                            <a href="<?php echo e(route('akundetail.transferLain', $akunDetail->id)); ?>" class="btn btn-success text-white">pemasukan lain</a>
                            <a href="<?php echo e(route('akundetail.transfer', $akunDetail->id)); ?>" class="btn btn-primary">transfer</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php echo e($bukubesars->links()); ?>

                <div class="table-responsive mt-3">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">tanggal</th>
                                <th scope="col">ket</th>
                                <th scope="col">debet</th>
                                <th scope="col">kredit</th>
                                <th scope="col">saldo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $bukubesars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bukubesar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($bukubesar->created_at); ?></td>
                                    <td><?php echo e($bukubesar->ket); ?></td>
                                    <td><?php echo e(number_format($bukubesar->debet, 0, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($bukubesar->kredit, 0, ',', '.')); ?></td>
                                    <td><?php echo e(number_format($bukubesar->saldo, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($bukubesars->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script>
        let table = new DataTable('#myTable');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/akundetails/bukubesar.blade.php ENDPATH**/ ?>