<?php $__env->startSection('title'); ?>
Kas Transfer Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        Kas Transfer
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("transfer.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($akunDetail->id); ?>" name="akun_detail_dari">
            <div class="form-group mb-3">
                <label class="required" for="nama">nama</label>
                <input disabled class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama" id="nama" value="<?php echo e(old('nama',$akunDetail->nama)); ?>" required>
                <?php if($errors->has('nama')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label for="akun_detail_tujuan">kas</label>
                <select class="form-select <?php echo e($errors->has('akun_detail_tujuan') ? 'is-invalid' : ''); ?>" name="akun_detail_tujuan" id="akun_detail_tujuan">
                    <?php $__currentLoopData = $kas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('akun_detail_tujuan') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('akun_detail_tujuan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('akun_detail_tujuan')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <label class="required" for="jumlah">jumlah</label>
                <input class="form-control <?php echo e($errors->has('jumlah') ? 'is-invalid' : ''); ?>" type="number" name="jumlah" id="jumlah" value="<?php echo e(old('jumlah')); ?>" required>
                <?php if($errors->has('jumlah')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jumlah')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group mb-3">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/akundetails/transfer.blade.php ENDPATH**/ ?>