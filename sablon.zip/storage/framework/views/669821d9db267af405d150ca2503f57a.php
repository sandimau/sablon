<?php $__env->startSection('title'); ?>
    Detail Konsumens
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        Detail Kontak
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group mb-3">
                <a class="btn btn-success" href="<?php echo e(route('kontaks.index')); ?>">
                    back
                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kontak_edit')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('kontaks.edit', $kontak->id)); ?>">
                        edit
                    </a>
                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th>
                                Id
                            </th>
                            <td>
                                <?php echo e($kontak->id); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Nama
                            </th>
                            <td>
                                <?php echo e($kontak->nama); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Kontak
                            </th>
                            <td>
                                <?php echo e($kontak->kontak); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                No Telp
                            </th>
                            <td>
                                <?php echo e($kontak->noTelp); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Email
                            </th>
                            <td>
                                <?php echo e($kontak->email); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Alamat
                            </th>
                            <td>
                                <?php echo e($kontak->alamat); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Customer Service
                            </th>
                            <td>
                                <?php if($kontak->ar): ?>
                                <?php echo e($kontak->ar->member->nama_lengkap); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Jenis
                            </th>
                            <td>
                                <?php echo e($kontak->konsumen === 1 ? 'konsumen' : ''); ?>

                                <?php echo e($kontak->supplier === 1 ? 'supplier' : ''); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sablon\resources\views/admin/kontaks/show.blade.php ENDPATH**/ ?>